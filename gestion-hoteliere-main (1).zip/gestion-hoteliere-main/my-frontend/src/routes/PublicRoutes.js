// This file can be used to group public route definitions
// For now, it's a placeholder as routes are in index.js
import React from 'react';
import { Route } from 'react-router-dom';
// Import public page components if you move them here

const PublicRoutes = () => {
  return (
    <>
      {/* Example: <Route path="/about" element={<AboutPage />} /> */}
    </>
  );
};

export default PublicRoutes;
