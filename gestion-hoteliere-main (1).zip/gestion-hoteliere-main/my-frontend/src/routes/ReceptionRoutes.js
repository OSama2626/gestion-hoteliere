// This file can be used to group reception-specific authenticated routes
import React from 'react';
import { Route } from 'react-router-dom';
// Import reception page components if you move them here
// import ProtectedRoute from './ProtectedRoute';

const ReceptionRoutes = () => {
  return (
    <>
      {/* Example: <Route path="/reception/feature" element={<ProtectedRoute role="reception"><ReceptionFeaturePage /></ProtectedRoute>} /> */}
    </>
  );
};

export default ReceptionRoutes;
