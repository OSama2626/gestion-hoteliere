// This file can be used to group admin-specific authenticated routes
import React from 'react';
import { Route } from 'react-router-dom';
// Import admin page components if you move them here
// import ProtectedRoute from './ProtectedRoute';

const AdminRoutes = () => {
  return (
    <>
      {/* Example: <Route path="/admin/feature" element={<ProtectedRoute role="admin"><AdminFeaturePage /></ProtectedRoute>} /> */}
    </>
  );
};

export default AdminRoutes;
