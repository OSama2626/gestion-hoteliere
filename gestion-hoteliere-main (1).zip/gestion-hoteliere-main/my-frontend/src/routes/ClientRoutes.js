// This file can be used to group client-specific authenticated routes
import React from 'react';
import { Route } from 'react-router-dom';
// Import client page components if you move them here
// import ProtectedRoute from './ProtectedRoute';

const ClientRoutes = () => {
  return (
    <>
      {/* Example: <Route path="/client/feature" element={<ProtectedRoute role="client"><ClientFeaturePage /></ProtectedRoute>} /> */}
    </>
  );
};

export default ClientRoutes;
