import React from 'react';

const ClientDashboardPage = () => <h1>Client Dashboard</h1>;

export default ClientDashboardPage;
