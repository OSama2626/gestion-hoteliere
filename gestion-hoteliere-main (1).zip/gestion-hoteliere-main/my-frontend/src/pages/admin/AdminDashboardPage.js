import React from 'react';

const AdminDashboardPage = () => <h1>Admin Dashboard</h1>;

export default AdminDashboardPage;
