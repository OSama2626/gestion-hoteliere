import React from 'react';

const UserManagementPage = () => <h1>User Management (Admin)</h1>;

export default UserManagementPage;
