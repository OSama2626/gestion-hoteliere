import React from 'react';

const ValidateReservationsPage = () => <h1>Validate Reservations (Admin)</h1>;

export default ValidateReservationsPage;
