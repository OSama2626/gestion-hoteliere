import React from 'react';

const ManageHotelsPage = () => <h1>Manage Hotels (Admin)</h1>;

export default ManageHotelsPage;
