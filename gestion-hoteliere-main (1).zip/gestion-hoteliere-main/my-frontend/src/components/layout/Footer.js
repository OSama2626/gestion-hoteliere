import React from 'react';
const Footer = () => (
  <footer>
    <p>&copy; 2024 Hotel Management System</p>
  </footer>
);
export default Footer;
