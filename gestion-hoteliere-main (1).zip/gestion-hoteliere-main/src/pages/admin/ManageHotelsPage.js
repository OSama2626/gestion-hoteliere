```javascript
import React from 'react';

const ManageHotelsPage = () => {
  return (
    <div>
      <h1>Manage Hotels</h1>
      <p>This is where admins can manage hotel listings.</p>
      {/* Add functionality to add, edit, delete hotels */}
    </div>
  );
};

export default ManageHotelsPage;
```
