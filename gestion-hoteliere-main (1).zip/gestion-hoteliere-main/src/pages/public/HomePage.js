```javascript
import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Home Page</h1>
      <p>Welcome to the Hotel Booking System!</p>
    </div>
  );
};

export default HomePage;
```
