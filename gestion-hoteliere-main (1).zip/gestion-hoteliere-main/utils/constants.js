const ROLES = {
  ADMIN: 'admin',
  HOTEL_MANAGER: 'hotel_manager',
  CLIENT: 'client',
  // Add any other roles if they exist or are anticipated
  // For now, these cover the known roles.
};

module.exports = {
  ROLES,
};
